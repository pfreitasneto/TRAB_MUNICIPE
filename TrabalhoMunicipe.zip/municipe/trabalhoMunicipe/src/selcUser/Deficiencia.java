package selcUser;

public class Deficiencia {
}
