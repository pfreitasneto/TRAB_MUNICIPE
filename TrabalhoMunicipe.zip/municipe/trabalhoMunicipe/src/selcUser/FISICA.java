package selcUser;

public class FISICA {
}
