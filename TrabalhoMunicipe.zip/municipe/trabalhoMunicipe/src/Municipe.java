public class Municipe {
    private String idMunicipe;
    private String nome;
    private String dataNasc;
    private String Nacionalidade;
    private String Naturalidade;
    private char sexo;
    private Endereço endereço;
    private Docs Docs;
    private RG RG;
    private String tel;
    private String cel;
    private String date;
    private int pne;
    private int estadoCivil;
    private int numeroDependentes;
    private String dataChegada;
    private int corPele;
    private String pai;
    private String mae;
    private String ocupação;
    private String cupomFiscal;
    private String associação;
    private String clube;
    private String sindicato;
    private String religião;


    public String getPai() {
        return pai;
    }

    public String getMae() {
        return mae;
    }

    public String getOcupação() {
        return ocupação;
    }

    public String getCupomFiscal(String s) {
        return cupomFiscal;
    }

    public void setCupomFiscal(String cupomFiscal) {
        this.cupomFiscal = cupomFiscal;
    }

    public String getPai(String s) {
        return pai;
    }

    public void setPai(String pai) {
        this.pai = pai;
    }

    public String getMae(String s) {
        return mae;
    }

    public void setMae(String mae) {
        this.mae = mae;
    }

    public String getOcupação(String s) {
        return ocupação;
    }

    public void setOcupação(String ocupação) {
        this.ocupação = ocupação;
    }

    public String getDataChegada() {
        return dataChegada;
    }

    public int getCorPele() {
        return corPele;
    }

    public void setCorPele(int corPele) {
        this.corPele = corPele;
    }

    public String getCel() {
        return cel;
    }

    public String getDataChegada(String s) {
        return dataChegada;
    }

    public void setDataChegada(String dataChegada) {
        this.dataChegada = dataChegada;
    }

    public String getTel() {
        return tel;
    }

    public String getCel(String s) {
        return cel;
    }

    public void setCel(String cel) {
        this.cel = cel;
    }

    public int getNumeroDependentes() {
        return numeroDependentes;
    }

    public int getEstadoCivil() {
        return estadoCivil;
    }

    public int getNumeroDependentes(String s) {
        return numeroDependentes;
    }

    public void setNumeroDependentes(int numeroDependentes) {
        this.numeroDependentes = numeroDependentes;
    }

    public char getSexo() {
        return sexo;
    }

    public int getEstadoCivil(int solteiro) {
        return estadoCivil;
    }

    public void setEstadoCivil(int estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public int getPne() {
        return pne;
    }

    public void setPne(int pne) {
        this.pne = pne;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTel(String s) {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getIdMunicipe() {
        return idMunicipe;
    }

    public void setIdMunicipe(String idMunicipe) {
        this.idMunicipe = idMunicipe;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    public String getNacionalidade() {
        return Nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        Nacionalidade = nacionalidade;
    }

    public String getNaturalidade() {
        return Naturalidade;
    }

    public void setNaturalidade(String naturalidade) {
        Naturalidade = naturalidade;
    }

    public char getSexo(int FEMININO) {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public Endereço getEndereço() {
        return endereço;
    }

    public void setEndereço(Endereço endereço) {
        this.endereço = endereço;
    }

    public Docs getDocs() {
        return Docs;
    }

    public void setDocs(Docs docs) {
        Docs = docs;
    }

    public RG getRG() {
        return RG;
    }

    public void setRG(RG RG) {
        this.RG = RG;
    }

    public void add(Municipe municipe) {
    }





    public String getAssociação() {
        return associação;
    }

    public void setAssociação(String associação) {
        this.associação = associação;
    }

    public String getClube() {
        return clube;
    }

    public void setClube(String clube) {
        this.clube = clube;
    }

    public String getSindicato() {
        return sindicato;
    }

    public void setSindicato(String sindicato) {
        this.sindicato = sindicato;
    }

    public String getReligião() {
        return religião;
    }

    public void setReligião(String religião) {
        this.religião = religião;
    }
}
