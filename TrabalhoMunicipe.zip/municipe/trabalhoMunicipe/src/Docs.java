public class Docs {
    private String CPF;
    private String tituloEleitor;
    private String seção;
    private int zona;

    public Docs(String CPF, String tituloEleitor, String seção, int zona) {
        this.CPF = CPF;
        this.tituloEleitor = tituloEleitor;
        this.seção = seção;
        this.zona = zona;
    }

    public Docs() {

    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getTituloEleitor() {
        return tituloEleitor;
    }

    public void setTituloEleitor(String tituloEleitor) {
        this.tituloEleitor = tituloEleitor;
    }

    public String getSeção() {
        return seção;
    }

    public void setSeção(String seção) {
        this.seção = seção;
    }

    public int getZona() {
        return zona;
    }

    public void setZona(int zona) {
        this.zona = zona;
    }

}
