public class RG {
    private int numRG;
    private String orgEmissor;
    private String uf;
    private String dataEmissão;


    public RG(int numRG, String orgEmissor, String uf) {
        this.numRG = numRG;
        this.orgEmissor = orgEmissor;
        this.uf = uf;
    }

    public RG() {

    }

    public String getDataEmissão() {
        return dataEmissão;
    }

    public void setDataEmissão(String dataEmissão) {
        this.dataEmissão = dataEmissão;
    }

    public int getNumRG() {
        return numRG;
    }

    public void setNumRG(int numRG) {
        this.numRG = numRG;
    }

    public String getOrgEmissor() {
        return orgEmissor;
    }

    public void setOrgEmissor(String orgEmissor) {
        this.orgEmissor = orgEmissor;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }


    public void setNumRG(String nextLine) {
    }
}
