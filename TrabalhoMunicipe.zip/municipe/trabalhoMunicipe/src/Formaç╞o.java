public class Formação {
    private String Escolaridade;
    private String Formação;
    private String NomeEscola;
    private int dataFormação;
    private String FormaçãoPretendida;
    private String voltarEstudar;

    public String getFormação() {
        return Formação;
    }

    public String getNomeEscola() {
        return NomeEscola;
    }

    public String getVoltarEstudar(String s) {
        return voltarEstudar;
    }

    public void setVoltarEstudar(String voltarEstudar) {
        this.voltarEstudar = voltarEstudar;
    }

    public String getFormaçãoPretendida(String s) {
        return FormaçãoPretendida;
    }

    public void setFormaçãoPretendida(String formaçãoPretendida) {
        FormaçãoPretendida = formaçãoPretendida;
    }

    public String getEscolaridade() {
        return Escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        Escolaridade = escolaridade;
    }

    public String getFormação(String s) {
        return Formação;
    }

    public void setFormação(String formação) {
        Formação = formação;
    }

    public String getNomeEscola(String s) {
        return NomeEscola;
    }

    public void setNomeEscola(String nomeEscola) {
        NomeEscola = nomeEscola;
    }

    public int getDataFormação() {
        return dataFormação;
    }

    public void setDataFormação(int dataFormação) {
        this.dataFormação = dataFormação;
    }

    public void getEscolaridade(String nextLine) {
    }

}
