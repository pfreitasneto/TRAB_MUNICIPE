public class Endereço {
    private String rua;
    private int num;
    private int CEP;
    private String bairro;
    private String cidade;
    private String estado;
    private String pais;

    public Endereço(){
        this.rua = rua;
        this.num = num;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.pais = pais;
    }

    public String getRua(String s) {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getNum(String s) {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getCEP() {
        return CEP;
    }

    public void setCEP(int CEP) {
        this.CEP = CEP;
    }

    public String getBairro(String s) {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade(String s) {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado(String s) {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getPais(String s) {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }


}
