import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Main {
    List<Municipe> municipe = new ArrayList<>();
    List<RG> rg = new ArrayList<>();
    private int selectSexo;
    public static int FISICA = 1;
    public static int MENTAL = 2;
    public static int AUDITIVA = 3;
    public static int VISUAL = 4;
    public static int NAO = 5;
    public static int Feminino = 01;
    public  static int Masculino = 02;
    public static int Solteiro = 1;
    public static int Casado = 2;
    public static int Separado = 3;
    public static int Concubinato = 4;
    public static int Viúvo = 5;
    public static int Divorciado = 6;
    public static int Branca = 1;
    public static int Negra = 2;
    public static int Amarelo = 3;
    public static int Pardo = 4;





    private void Menu(){
        System.out.println("\n\n");
        System.out.println("+-------------------------------------------+");
        System.out.println("|        Menu de Opções                     |");
        System.out.println("+-------------------------------------------+");
        System.out.println("| 1 - Cadastrar Municipe                   |");
        System.out.println("| 2 - Imprimir relatório do municipe       |");
        System.out.println("| 3 - Exibir o menu de opções              |");
        System.out.println("| 4 - Excluir munícipe                     |");
        System.out.println("| 5 - Sair                                 |");
        System.out.println("+-------------------------------------------+");
    }

    private void cadastrarMunicipe(){
        SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyy");
        Scanner leitor = new Scanner(System.in);
        Municipe municipe = new Municipe ();
        Docs docs = new Docs();
        RG rg = new RG();
        Endereço endereço = new Endereço();
        Formação formação = new Formação();


        System.out.print("BEM VINDO AO SISTEMA DE CADASTRO\n\n");


        System.out.print("ID do Municipe: ");
        municipe.setIdMunicipe(leitor.next());

        System.out.print("----------------------------\n");
        System.out.print("       DASOS PESSOAIS       \n");
        System.out.print("----------------------------\n");

        System.out.print("Nome do Municipe: ");
        leitor.next();
        municipe.setNome(leitor.nextLine());

        System.out.print("CPF:");
        leitor.next();
        docs.setCPF(leitor.nextLine());

        System.out.print("RG: ");
        leitor.next();
        rg.setNumRG(leitor.nextLine());

        System.out.print("Orgão emissor: ");
        leitor.next();
        rg.setOrgEmissor(leitor.nextLine());

        System.out.print("UF: ");
        leitor.next();
        rg.setUf(leitor.nextLine());

        System.out.print("Data de Emissão(RG): ");
        leitor.next();
        rg.setDataEmissão(leitor.nextLine());


        System.out.print("Titulo de Eleitor:");
        leitor.next();
        docs.setTituloEleitor(leitor.nextLine());

        System.out.print("Seção:");
        leitor.next();
        docs.setSeção(leitor.nextLine());

        System.out.print("Zona:");
        docs.setZona(leitor.nextInt());

        System.out.print("Data de Nascimento: ");
        leitor.next();
        municipe.setDataNasc(leitor.nextLine());

        System.out.print("Naturalidade:");
        leitor.next();
        municipe.setNaturalidade(leitor.nextLine());

        System.out.print("Nacionalidade:");
        leitor.next();
        municipe.setNacionalidade(leitor.nextLine());

        //PERGUNTA PARA O USUARIO SEXO
        System.out.print("\n        Seu Sexo       \n");
        System.out.println("+-------------------------+");
        System.out.println("|1 - Feminino             |");
        System.out.println("|2 - Masculino            |");
        System.out.println("+-------------------------+");
        System.out.print("Inserir a opção: ");

        int selectSexo = leitor.nextInt();

        switch (selectSexo){
            case 1:
                municipe.getSexo(Main.Feminino);
            case 2:
                municipe.getSexo(Main.Masculino);
        }

        //PERGUNTA PARA O ESTADO CIVIL
        System.out.print("        Estado Civil        \n");
        System.out.println("+-------------------------+");
        System.out.println("|1 - Solteiro             |");
        System.out.println("|2 - Casado               |");
        System.out.println("|3 - Separado             |");
        System.out.println("|4 - Concubinato          |");
        System.out.println("|5 - Viúvo                |");
        System.out.println("|6 - Divorciado           |");
        System.out.println("+-------------------------+");
        System.out.print("Inserir a opção: ");

        int selectEstadoCivil = leitor.nextInt();

        switch (selectEstadoCivil){
            case 1:
                municipe.getEstadoCivil(Main.Solteiro);
            case 2:
                municipe.getEstadoCivil(Main.Casado);
            case 3:
                municipe.getEstadoCivil(Main.Separado);
            case 4:
                municipe.getEstadoCivil(Main.Concubinato);
            case 5:
                municipe.getEstadoCivil(Main.Viúvo);
            case 6:
                municipe.getEstadoCivil(Main.Divorciado);
        }

        System.out.print("Numero de dependentes: ");
        leitor.next();
        municipe.getNumeroDependentes(leitor.nextLine());

        System.out.print("Nome da rua:");
        leitor.next();
        endereço.getRua(leitor.nextLine());

        System.out.print("Numero da residencia:");
        leitor.next();
        endereço.getNum(leitor.nextLine());

        System.out.print("Bairro:");
        leitor.next();
        endereço.getBairro(leitor.nextLine());

        System.out.print("Cidade:");
        leitor.next();
        endereço.getCidade(leitor.nextLine());

        System.out.print("Estado:");
        leitor.next();
        endereço.getEstado(leitor.nextLine());

        System.out.print("Pais:");
        leitor.next();
        endereço.getPais(leitor.nextLine());

        System.out.print("Telefone com DDD:");
        leitor.next();
        municipe.getTel(leitor.nextLine());

        System.out.print("Numero de celular com DDD:");
        leitor.next();
        municipe.getCel(leitor.nextLine());

        System.out.print("Data de Chegada:");
        leitor.next();
        municipe.getDataChegada(leitor.nextLine());

        //PERGUNTA AO USUARIO A COR DA PELE
        System.out.print("\n        Cor da pele       \n");
        System.out.println("+-------------------------+");
        System.out.println("|1 - Branca             |");
        System.out.println("|2 - Negra              |");
        System.out.println("|3 - Amarela            |");
        System.out.println("|4 - Parda              |");
        System.out.println("+-------------------------+");
        System.out.print("Inserir a opção: ");

        int selectCorPele = leitor.nextInt();

        switch (selectCorPele){
            case 1 :
                municipe.setCorPele(Main.Branca);
            case 2 :
                municipe.setCorPele(Main.Negra);
            case 3 :
                municipe.setCorPele(Main.Amarelo);
            case 4 :
                municipe.setCorPele(Main.Pardo);
        }

        System.out.print("----------------------------\n");
        System.out.print("        FILIAÇÃO        \n");
        System.out.print("----------------------------\n");

        System.out.print("Nome do Pai:");
        leitor.next();
        municipe.getPai(leitor.nextLine());

        System.out.print("Nome da Mãe:");
        leitor.next();
        municipe.getMae(leitor.nextLine());

        System.out.print("Ocupação:");
        leitor.next();
        municipe.getOcupação(leitor.nextLine());

        System.out.print("----------------------------\n");
        System.out.print("        ESCOLARIDADE        \n");
        System.out.print("----------------------------\n");


        System.out.print("Escolaridade:");
        leitor.next();
        formação.getEscolaridade(leitor.nextLine());

        System.out.print("Formação:");
        leitor.next();
        formação.getFormação(leitor.nextLine());

        System.out.print("Estituição de ensino atual:");
        leitor.next();
        formação.getNomeEscola(leitor.nextLine());

        System.out.print("Pretende voltar a Estudar ?:\n");
        System.out.print("------RESPONDA------\n");
        System.out.print("(S) para Sim:\n");
        System.out.print("(N) para Não ?:\n");
        System.out.print("Inserir a opção desejada: ");
        leitor.next();
        formação.getVoltarEstudar(leitor.nextLine());


        //PERGUNTA AO USUARIO SE POSSUI NECESSIDADE
        System.out.print("  É portador de necessidades? \n");
        System.out.println("+-------------------------+");
        System.out.println("| 1 - Física              |");
        System.out.println("| 2 - Mental              |");
        System.out.println("| 3 - Auditiva            |");
        System.out.println("| 4 - Visual              |");
        System.out.println("| 5 - Não                 |");
        System.out.println("+-------------------------+\n");
        System.out.print("Favor inserir a oção desejanda: ");
        int selcUser = leitor.nextInt();


        switch(selcUser){
            case 1:
                municipe.setPne(Main.FISICA);
                break;
            case 2:
                municipe.setPne(Main.MENTAL);
                break;
            case 3:
                municipe.setPne(Main.AUDITIVA);
                break;
            case 4:
                municipe.setPne(Main.VISUAL);
            default:
                municipe.setPne(Main.NAO);
        }

        System.out.print("Estudo pretendido:");
        leitor.next();
        formação.getFormaçãoPretendida(leitor.nextLine());

        System.out.print("Deseja cupom fiscal ?:\n");
        System.out.print("------RESPONDA------\n");
        System.out.print("(S) para Sim:\n");
        System.out.print("(N) para Não ?:\n");
        System.out.print("Inserir a opção desejada: ");
        leitor.next();
        municipe.getCupomFiscal(leitor.nextLine());


        System.out.print("Associação: ");
        leitor.next();
        municipe.setAssociação(leitor.nextLine());

        System.out.print("Clube: ");
        leitor.next();
        municipe.setClube(leitor.nextLine());

        System.out.print("Sindicato: ");
        leitor.next();
        municipe.setSindicato(leitor.nextLine());

        System.out.print("Religião: ");
        leitor.next();
        municipe.setReligião(leitor.nextLine());

        System.out.println("Dados impresso na tela");
        System.out.println("\nNome: " + municipe.getNome());
    }





    //IMPRIMI USUARIO
    private void imprimirMunicipe() {
        for (Municipe municipe : municipe) {
            System.out.print("Nome: " + municipe.getNome());
            System.out.print(("Data de Nascimento" + municipe.getDataNasc()));
            //System.out.print(("Data de Nascimento" + docs.getDataNasc()));
            System.out.print("CPF: ");
            System.out.print("\n\n");
        }
    }

    private void Excluir(){
        Object Docs = null;
        Object Endereço = null;
        Object Formação = null;
        Object Main = null;
        Object Municipe = null;
        Object RG = null;

    }



    public static void main(String[] args){
        short opcao = 3;
        Scanner leitor = new Scanner(System.in);
        Main main = new Main ();

        do{
            main.Menu();

            System.out.print("Digite a opção desejada: ");
            opcao = leitor.nextShort();

            switch(opcao){
                case 1:
                    main.cadastrarMunicipe();
                    break;
                case 2:
                    main.imprimirMunicipe();
                    break;
                case 3:
                    main.Menu();
                    break;
                case 4:
                    main.Excluir();
                default:
                    System.out.println(" \n------------ATENÇÃO------------" + "\n   Opção digitada é invalida");
                    main.Menu();
            }
        }while(opcao != 4);
    }
}
